export default function App() {
   
    return (
        <main>
            <h1 className="title">Are you going to study tonight?</h1>
            <button className="value">Yes</button>
        </main>
    )
}
