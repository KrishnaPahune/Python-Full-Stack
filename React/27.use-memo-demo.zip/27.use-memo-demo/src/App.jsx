import React, { useMemo, useState } from "react";

function App() {
  console.log("App Component Rendered");

  const [todos, setTodos] = useState([]);
  
  const [count, setCount] = useState(0);

  function incrementCount(){
    setCount(prev => prev + 1)
  }
  function addTodo() {
    setTodos((prevTodos) => {
      return [...prevTodos, "New Todo"];
    });
  }

  let memoizedValue = useMemo(() => {
    let result = timeConsumingFunction(count);
    return result;
  }, [count])
  
  function timeConsumingFunction(n) {
    console.log("calculating")
    for(let i=0; i<1000000000; i++) {
      n = n+1;
    }
    return n;
  }
  return (
    <div>
      <h1>useMemo Hook</h1>
      <button onClick={addTodo}>Add todo</button>

      {todos.map((todo, index) => {
        return <li key={index}>{todo}</li>;
      })}

      <hr />
      <h2>Count: {count}</h2>
      <button onClick={incrementCount}>increment Count</button>

      <p>Value returned by time consuming function: {memoizedValue}</p>

    </div>
  );
}

export default App;
